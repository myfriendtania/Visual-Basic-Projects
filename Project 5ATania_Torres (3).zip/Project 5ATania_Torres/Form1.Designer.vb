﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WorkshopSelector
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddWorkshop = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.lstLocation = New System.Windows.Forms.ListBox()
        Me.txtTotalCost = New System.Windows.Forms.TextBox()
        Me.lstWorkshop = New System.Windows.Forms.ListBox()
        Me.lstCosts = New System.Windows.Forms.ListBox()
        Me.lblPickaWorkshopHere = New System.Windows.Forms.Label()
        Me.lblPickALocationHere = New System.Windows.Forms.Label()
        Me.lblListOfCostsHere = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnAddWorkshop
        '
        Me.btnAddWorkshop.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.btnAddWorkshop.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddWorkshop.Location = New System.Drawing.Point(132, 356)
        Me.btnAddWorkshop.Name = "btnAddWorkshop"
        Me.btnAddWorkshop.Size = New System.Drawing.Size(110, 46)
        Me.btnAddWorkshop.TabIndex = 2
        Me.btnAddWorkshop.Text = "Add Workshop"
        Me.btnAddWorkshop.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(264, 356)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(110, 46)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate Total"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(396, 356)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(110, 46)
        Me.btnReset.TabIndex = 4
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(525, 356)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(110, 46)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTotalCost
        '
        Me.lblTotalCost.AutoSize = True
        Me.lblTotalCost.Font = New System.Drawing.Font("Rockwell", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCost.Location = New System.Drawing.Point(255, 287)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(89, 18)
        Me.lblTotalCost.TabIndex = 6
        Me.lblTotalCost.Text = "Total Cost:"
        '
        'lstLocation
        '
        Me.lstLocation.AccessibleName = "lstLocation"
        Me.lstLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstLocation.FormattingEnabled = True
        Me.lstLocation.ItemHeight = 16
        Me.lstLocation.Items.AddRange(New Object() {"Austin", "Chicago", "Dallas", "Orlando", "Phoenix", "Raleigh"})
        Me.lstLocation.Location = New System.Drawing.Point(310, 67)
        Me.lstLocation.Name = "lstLocation"
        Me.lstLocation.Size = New System.Drawing.Size(155, 180)
        Me.lstLocation.TabIndex = 1
        '
        'txtTotalCost
        '
        Me.txtTotalCost.AccessibleName = "txtTotalCost"
        Me.txtTotalCost.Location = New System.Drawing.Point(350, 285)
        Me.txtTotalCost.Name = "txtTotalCost"
        Me.txtTotalCost.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalCost.TabIndex = 7
        '
        'lstWorkshop
        '
        Me.lstWorkshop.AccessibleName = "lstWorkshop"
        Me.lstWorkshop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstWorkshop.FormattingEnabled = True
        Me.lstWorkshop.ItemHeight = 16
        Me.lstWorkshop.Items.AddRange(New Object() {"Handling Stress", "Time Management", "Supervision Skills", "Negotiation", "How to Interview"})
        Me.lstWorkshop.Location = New System.Drawing.Point(132, 67)
        Me.lstWorkshop.Name = "lstWorkshop"
        Me.lstWorkshop.Size = New System.Drawing.Size(155, 180)
        Me.lstWorkshop.TabIndex = 0
        '
        'lstCosts
        '
        Me.lstCosts.AccessibleName = "lstCosts"
        Me.lstCosts.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstCosts.FormattingEnabled = True
        Me.lstCosts.ItemHeight = 16
        Me.lstCosts.Location = New System.Drawing.Point(489, 67)
        Me.lstCosts.Name = "lstCosts"
        Me.lstCosts.Size = New System.Drawing.Size(155, 180)
        Me.lstCosts.TabIndex = 2
        '
        'lblPickaWorkshopHere
        '
        Me.lblPickaWorkshopHere.AutoSize = True
        Me.lblPickaWorkshopHere.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPickaWorkshopHere.Location = New System.Drawing.Point(129, 39)
        Me.lblPickaWorkshopHere.Name = "lblPickaWorkshopHere"
        Me.lblPickaWorkshopHere.Size = New System.Drawing.Size(151, 19)
        Me.lblPickaWorkshopHere.TabIndex = 8
        Me.lblPickaWorkshopHere.Text = "Pick a Workshop: "
        '
        'lblPickALocationHere
        '
        Me.lblPickALocationHere.AutoSize = True
        Me.lblPickALocationHere.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPickALocationHere.Location = New System.Drawing.Point(307, 39)
        Me.lblPickALocationHere.Name = "lblPickALocationHere"
        Me.lblPickALocationHere.Size = New System.Drawing.Size(136, 19)
        Me.lblPickALocationHere.TabIndex = 9
        Me.lblPickALocationHere.Text = "Pick a Location:"
        '
        'lblListOfCostsHere
        '
        Me.lblListOfCostsHere.AutoSize = True
        Me.lblListOfCostsHere.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblListOfCostsHere.Location = New System.Drawing.Point(486, 39)
        Me.lblListOfCostsHere.Name = "lblListOfCostsHere"
        Me.lblListOfCostsHere.Size = New System.Drawing.Size(112, 19)
        Me.lblListOfCostsHere.TabIndex = 10
        Me.lblListOfCostsHere.Text = "List of Costs:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 419)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Tania Torres"
        '
        'WorkshopSelector
        '
        Me.AccessibleName = "formWorkshopSelector"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblListOfCostsHere)
        Me.Controls.Add(Me.lblPickALocationHere)
        Me.Controls.Add(Me.lblPickaWorkshopHere)
        Me.Controls.Add(Me.lstCosts)
        Me.Controls.Add(Me.lstLocation)
        Me.Controls.Add(Me.lstWorkshop)
        Me.Controls.Add(Me.txtTotalCost)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.btnAddWorkshop)
        Me.Name = "WorkshopSelector"
        Me.Text = "Workshop Selector"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAddWorkshop As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents lstLocation As ListBox
    Friend WithEvents txtTotalCost As TextBox
    Friend WithEvents lstWorkshop As ListBox
    Friend WithEvents lstCosts As ListBox
    Friend WithEvents lblPickaWorkshopHere As Label
    Friend WithEvents lblPickALocationHere As Label
    Friend WithEvents lblListOfCostsHere As Label
    Friend WithEvents Label1 As Label
End Class
